package com.example.addressbookapp.dto;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
    @NoArgsConstructor
    public class LoginDTO {
        public String emailId;
        public String password;
    }

