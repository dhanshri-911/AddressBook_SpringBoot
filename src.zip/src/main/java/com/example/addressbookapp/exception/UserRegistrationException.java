package com.example.addressbookapp.exception;


    public class UserRegistrationException  extends  RuntimeException{
        public UserRegistrationException(String message)
        {
            super(message);
        }
    }

