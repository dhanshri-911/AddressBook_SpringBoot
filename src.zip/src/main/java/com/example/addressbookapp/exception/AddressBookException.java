package com.example.addressbookapp.exception;


    public class AddressBookException extends RuntimeException {

        public AddressBookException(String message) {
            super(message);
        }
}
